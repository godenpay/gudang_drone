<?php
// Menu/fitur yang boleh diberikan admin ke user non-admin secara terpisah.
// Dashboard, lihat Inventaris (read-only), Riwayat, dan Pengaturan (profil sendiri)
// SENGAJA tidak masuk sini karena selalu terbuka untuk semua user yang login.
// Role admin_gudang selalu lolos semua permission ini tanpa perlu di-set.
define('VALID_MENU_PERMISSIONS', ['inbound', 'outbound', 'loans', 'inventory_manage']);

function sanitizePermissions($input) {
    if (!is_array($input)) return [];
    $clean = [];
    foreach ($input as $p) {
        if (is_string($p) && in_array($p, VALID_MENU_PERMISSIONS, true) && !in_array($p, $clean, true)) {
            $clean[] = $p;
        }
    }
    return $clean;
}
