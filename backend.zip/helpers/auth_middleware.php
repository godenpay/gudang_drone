<?php
require_once __DIR__ . '/jwt.php';
require_once __DIR__ . '/../config/database.php';

/**
 * Memvalidasi token JWT dan (opsional) membatasi akses ke role tertentu.
 * $allowedRoles kosong = semua role yang sudah login boleh akses.
 * Contoh: requireAuth(['admin_gudang']) -> hanya Admin Gudang.
 */
function requireAuth($allowedRoles = []) {
    $token = getBearerToken();
    if (!$token) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Token tidak ditemukan. Silakan login kembali.']);
        exit;
    }

    $payload = verifyJWT($token);
    if (!$payload) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Sesi tidak valid atau sudah kadaluarsa. Silakan login kembali.']);
        exit;
    }

    if (!empty($allowedRoles) && !in_array($payload['role'], $allowedRoles, true)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Anda tidak memiliki hak akses untuk aksi ini. Hubungi Admin Gudang.']);
        exit;
    }

    return $payload;
}

/**
 * Memvalidasi token JWT lalu memastikan user berhak atas menu/fitur tertentu.
 * Beda dengan requireAuth(): daftar hak akses diambil LANGSUNG dari database
 * (bukan dari isi token) supaya begitu Admin mencabut akses seorang user,
 * user itu langsung diblokir di request berikutnya, tanpa harus menunggu
 * token lamanya kedaluwarsa (bisa sampai 8 jam kalau hanya andalkan token).
 *
 * Role 'admin_gudang' selalu lolos, apa pun isi kolom permissions-nya.
 */
function requirePermission($menuKey) {
    $payload = requireAuth();

    if ($payload['role'] === 'admin_gudang') {
        return $payload;
    }

    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT permissions FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$payload['user_id']]);
    $row = $stmt->fetch();

    $permissions = [];
    if ($row && !empty($row['permissions'])) {
        $decoded = json_decode($row['permissions'], true);
        if (is_array($decoded)) {
            $permissions = $decoded;
        }
    }

    if (!in_array($menuKey, $permissions, true)) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Anda tidak memiliki hak akses untuk fitur ini. Hubungi Admin Gudang.']);
        exit;
    }

    return $payload;
}
