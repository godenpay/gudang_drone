<?php
// Parser .env sederhana, tanpa dependency (tidak butuh Composer).
// Panggil load_env() sekali di awal, sebelum require db_config.php.

function load_env($path) {
    if (!file_exists($path)) {
        throw new Exception("File .env tidak ditemukan di: $path");
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || strpos($line, '#') === 0) continue; // skip komentar/baris kosong
        if (strpos($line, '=') === false) continue;

        list($key, $value) = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        // buang tanda kutip pembungkus kalau ada
        $value = trim($value, "\"'");

        if (!getenv($key)) {
            putenv("$key=$value");
            $_ENV[$key] = $value;
        }
    }
}
