-- ============================================================
-- SKEMA DATABASE - GTI WMS (PT General Technology Indonesia)
-- Import file ini via phpMyAdmin di cPanel > MySQL Databases
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    role          ENUM('admin_gudang','manajer') NOT NULL DEFAULT 'admin_gudang',
    -- Daftar menu tambahan yang boleh diakses user non-admin, disimpan sebagai
    -- JSON array string, contoh: ["inbound","outbound","loans","inventory_manage"].
    -- Kosong/NULL = user hanya bisa lihat Dashboard, Inventaris (read-only), Riwayat.
    -- Role admin_gudang SELALU dapat akses penuh terlepas dari isi kolom ini.
    permissions   JSON DEFAULT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Jika tabel users sudah ada dari instalasi sebelumnya,
-- jalankan ALTER ini secara manual satu kali:
-- ALTER TABLE users ADD COLUMN permissions JSON DEFAULT NULL AFTER role;
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS inventory (
    id          VARCHAR(30) PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    category    ENUM('Drone','Sparepart','Baterai','Aksesoris') NOT NULL,
    purpose     ENUM('Jual','Demo-Project') NOT NULL DEFAULT 'Jual',
    stock       INT NOT NULL DEFAULT 0,
    min_stock   INT NOT NULL DEFAULT 0,
    location    VARCHAR(30),
    price       DECIMAL(15,2) NOT NULL DEFAULT 0,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Jika tabel inventory sudah ada dari instalasi sebelumnya,
-- jalankan baris ALTER ini secara manual satu kali:
-- ALTER TABLE inventory ADD COLUMN purpose ENUM('Jual','Demo-Project') NOT NULL DEFAULT 'Jual' AFTER category;
-- ------------------------------------------------------------

-- Riwayat peminjaman drone untuk keperluan demo / project.
-- Dipisah dari tabel `transactions` karena siklus hidupnya beda:
-- ada tanggal pinjam, target kembali, dan status yang berubah seiring waktu.
CREATE TABLE IF NOT EXISTS loans (
    id                    VARCHAR(30) PRIMARY KEY,
    item_id               VARCHAR(30) NOT NULL,
    item_name             VARCHAR(150) NOT NULL,
    qty                   INT NOT NULL,
    borrower_name         VARCHAR(150) NOT NULL,
    project_name          VARCHAR(150) NOT NULL,
    notes                 VARCHAR(255) DEFAULT NULL,
    loan_date             DATE NOT NULL,
    expected_return_date  DATE NOT NULL,
    actual_return_date    DATE DEFAULT NULL,
    condition_note        VARCHAR(255) DEFAULT NULL,
    status                ENUM('Dipinjam','Dikembalikan','Terlambat') NOT NULL DEFAULT 'Dipinjam',
    created_by            INT DEFAULT NULL,
    created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES inventory(id) ON DELETE RESTRICT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_item (item_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS transactions (
    id           VARCHAR(30) PRIMARY KEY,
    type         ENUM('INBOUND','OUTBOUND') NOT NULL,
    item_id      VARCHAR(30) NOT NULL,
    item_name    VARCHAR(150) NOT NULL,
    qty          INT NOT NULL,
    supplier     VARCHAR(150) DEFAULT NULL,
    po_number    VARCHAR(50) DEFAULT NULL,
    destination  VARCHAR(150) DEFAULT NULL,
    status       VARCHAR(30) NOT NULL DEFAULT 'Selesai',
    created_by   INT DEFAULT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES inventory(id) ON DELETE RESTRICT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_item (item_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------------
-- Seed data awal (inventory) - aman untuk di-import langsung
-- --------------------------------------------------------------
INSERT INTO inventory (id, name, category, purpose, stock, min_stock, location, price) VALUES
('GTI-DRN-001', 'GTI Agras T40 (Pertanian)', 'Drone', 'Jual', 12, 5, 'A-01-01', 150000000),
('GTI-DRN-002', 'DJI Mavic 3 Enterprise', 'Drone', 'Jual', 8, 10, 'A-01-02', 45000000),
('GTI-DRN-003', 'Autel EVO Max 4T', 'Drone', 'Jual', 4, 5, 'A-02-01', 95000000),
('GTI-DRN-DEMO-001', 'DJI Mavic 3 Enterprise (Unit Demo)', 'Drone', 'Demo-Project', 3, 1, 'D-01-01', 45000000),
('GTI-DRN-DEMO-002', 'Autel EVO Max 4T (Unit Demo)', 'Drone', 'Demo-Project', 2, 1, 'D-01-02', 95000000),
('GTI-PRP-001', 'Propeller Carbon Fiber 30"', 'Sparepart', 'Jual', 150, 50, 'B-01-01', 1500000),
('GTI-BAT-001', 'Smart Flight Battery 30000mAh', 'Baterai', 'Jual', 35, 20, 'C-01-01', 12000000),
('GTI-CTRL-001', 'Smart Controller Pro v2', 'Aksesoris', 'Jual', 15, 10, 'C-02-01', 18000000)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- --------------------------------------------------------------
-- CATATAN: Akun user (admin_gudang / manajer) SENGAJA TIDAK
-- di-seed di sini. Password hash yang sama di-copy-paste ke banyak
-- instalasi adalah kebiasaan yang gampang bocor.
-- Jalankan backend/setup_admin.php SATU KALI via browser setelah
-- upload untuk membuat akun dengan hash yang benar dari server
-- Anda sendiri, lalu HAPUS file itu. Lihat README_DEPLOY.md.
-- --------------------------------------------------------------

-- ------------------------------------------------------------
-- MIGRASI: alur approval untuk role staff (outbound & peminjaman)
-- Jalankan manual satu kali kalau tabel sudah ada dari instalasi sebelumnya:
-- ALTER TABLE loans MODIFY COLUMN status ENUM('Menunggu Approval','Dipinjam','Dikembalikan','Terlambat','Ditolak') NOT NULL DEFAULT 'Dipinjam';
-- (Kolom transactions.status sudah VARCHAR, tidak perlu ALTER.)
-- ------------------------------------------------------------
