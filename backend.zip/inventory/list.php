<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requireAuth(); // Admin Gudang & Manajer sama-sama boleh lihat

$pdo = getDB();
$stmt = $pdo->query("SELECT id, name, category, purpose, stock, min_stock AS minStock, location
                      FROM inventory ORDER BY created_at DESC");

echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
