<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requirePermission('inventory_manage');

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$id = $_GET['id'] ?? '';
if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID barang wajib disertakan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$name     = trim($input['name'] ?? '');
$category = trim($input['category'] ?? '');
$purpose  = trim($input['purpose'] ?? 'Jual');
$minStock = (int)($input['minStock'] ?? 0);
$location = trim($input['location'] ?? '');

$validCategories = ['Drone', 'Sparepart', 'Baterai', 'Aksesoris', 'Laptop'];
$validPurposes    = ['Jual', 'Demo-Project'];
if ($name === '' || !in_array($category, $validCategories, true) || !in_array($purpose, $validPurposes, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Nama, kategori, dan peruntukan (valid) wajib diisi.']);
    exit;
}

$pdo = getDB();
$stmt = $pdo->prepare("UPDATE inventory SET name = ?, category = ?, purpose = ?, min_stock = ?, location = ? WHERE id = ?");
$stmt->execute([$name, $category, $purpose, $minStock, $location, $id]);

if ($stmt->rowCount() === 0) {
    // Cek apakah memang tidak ada perubahan, atau ID tidak ditemukan
    $check = $pdo->prepare("SELECT id FROM inventory WHERE id = ?");
    $check->execute([$id]);
    if (!$check->fetch()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Barang tidak ditemukan.']);
        exit;
    }
}

echo json_encode(['success' => true, 'message' => 'Master data berhasil diperbarui.']);
