<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requirePermission('inventory_manage');

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$id = $_GET['id'] ?? '';
if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID barang wajib disertakan.']);
    exit;
}

$pdo = getDB();

$stmt = $pdo->prepare("SELECT stock FROM inventory WHERE id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch();

if (!$item) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Barang tidak ditemukan.']);
    exit;
}

if ($item['stock'] > 0) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Tidak dapat menghapus item dengan stok lebih dari 0.']);
    exit;
}

$del = $pdo->prepare("DELETE FROM inventory WHERE id = ?");
$del->execute([$id]);

echo json_encode(['success' => true, 'message' => 'Barang berhasil dihapus dari master data.']);
