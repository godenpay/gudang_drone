<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requirePermission('inventory_manage');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$id       = trim($input['id'] ?? '');
$name     = trim($input['name'] ?? '');
$category = trim($input['category'] ?? '');
$purpose  = trim($input['purpose'] ?? 'Jual');
$minStock = (int)($input['minStock'] ?? 0);
$location = trim($input['location'] ?? '');

$validCategories = ['Drone', 'Sparepart', 'Baterai', 'Aksesoris', 'Laptop'];
$validPurposes    = ['Jual', 'Demo-Project'];

if ($id === '' || $name === '' || !in_array($category, $validCategories, true) || !in_array($purpose, $validPurposes, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'SKU, nama, kategori, dan peruntukan (valid) wajib diisi.']);
    exit;
}

$pdo = getDB();

$check = $pdo->prepare("SELECT id FROM inventory WHERE id = ?");
$check->execute([$id]);
if ($check->fetch()) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'SKU sudah ada di sistem.']);
    exit;
}

$stmt = $pdo->prepare("INSERT INTO inventory (id, name, category, purpose, stock, min_stock, location)
                        VALUES (?, ?, ?, ?, 0, ?, ?)");
$stmt->execute([$id, $name, $category, $purpose, $minStock, $location]);

echo json_encode(['success' => true, 'message' => 'Master data berhasil ditambahkan.']);
