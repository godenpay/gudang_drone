<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

$payload = requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID user tidak valid.']);
    exit;
}

if ($id === (int)$payload['user_id']) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Anda tidak bisa menghapus akun Anda sendiri.']);
    exit;
}

$pdo = getDB();

// created_by di transactions/loans pakai ON DELETE SET NULL, jadi aman dihapus.
$stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
$stmt->execute([$id]);

if ($stmt->rowCount() === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'User tidak ditemukan.']);
    exit;
}

echo json_encode(['success' => true, 'message' => 'User berhasil dihapus.']);
