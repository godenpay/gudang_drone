<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/permissions.php';

requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$username  = trim($input['username'] ?? '');
$password  = (string)($input['password'] ?? '');
$fullName  = trim($input['full_name'] ?? '');
$role      = $input['role'] ?? 'manajer';
$permissions = sanitizePermissions($input['permissions'] ?? []);

if ($username === '' || $password === '' || $fullName === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username, password, dan nama lengkap wajib diisi.']);
    exit;
}
if (!preg_match('/^[a-zA-Z0-9_.]{3,50}$/', $username)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username hanya boleh huruf, angka, titik, underscore (3-50 karakter).']);
    exit;
}
if (strlen($password) < 8) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password minimal 8 karakter.']);
    exit;
}
if (!in_array($role, ['admin_gudang', 'manajer', 'staff'], true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Role tidak valid.']);
    exit;
}

$pdo = getDB();

$check = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
$check->execute([$username]);
if ($check->fetch()) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Username sudah dipakai.']);
    exit;
}

// Admin selalu punya akses penuh, tidak perlu daftar permission eksplisit.
if ($role === 'admin_gudang') {
    $permissions = [];
}

$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("INSERT INTO users (username, password_hash, full_name, role, permissions) VALUES (?, ?, ?, ?, ?)");
$stmt->execute([$username, $hash, $fullName, $role, json_encode($permissions)]);

echo json_encode([
    'success' => true,
    'message' => 'User baru berhasil dibuat.',
    'data' => [
        'id' => (int)$pdo->lastInsertId(),
        'username' => $username,
        'full_name' => $fullName,
        'role' => $role,
        'permissions' => $permissions,
    ],
]);
