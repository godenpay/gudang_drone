<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/permissions.php';

$payload = requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID user tidak valid.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$fullName    = trim($input['full_name'] ?? '');
$role        = $input['role'] ?? 'manajer';
$permissions = sanitizePermissions($input['permissions'] ?? []);
$newPassword = (string)($input['new_password'] ?? '');

if ($fullName === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Nama lengkap wajib diisi.']);
    exit;
}
if (!in_array($role, ['admin_gudang', 'manajer', 'staff'], true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Role tidak valid.']);
    exit;
}
if ($newPassword !== '' && strlen($newPassword) < 8) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password baru minimal 8 karakter.']);
    exit;
}

$pdo = getDB();

$existing = $pdo->prepare("SELECT id, role FROM users WHERE id = ? LIMIT 1");
$existing->execute([$id]);
$target = $existing->fetch();
if (!$target) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'User tidak ditemukan.']);
    exit;
}

// Cegah admin menurunkan role akunnya sendiri -> resiko admin terkunci
// dari fitur Manajemen User tanpa ada admin lain yang bisa memulihkan.
if ($id === (int)$payload['user_id'] && $role !== 'admin_gudang') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Anda tidak bisa menurunkan role akun Anda sendiri.']);
    exit;
}

if ($role === 'admin_gudang') {
    $permissions = [];
}

if ($newPassword !== '') {
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, role = ?, permissions = ?, password_hash = ? WHERE id = ?");
    $stmt->execute([$fullName, $role, json_encode($permissions), $hash, $id]);
} else {
    $stmt = $pdo->prepare("UPDATE users SET full_name = ?, role = ?, permissions = ? WHERE id = ?");
    $stmt->execute([$fullName, $role, json_encode($permissions), $id]);
}

echo json_encode(['success' => true, 'message' => 'Data user berhasil diperbarui.']);
