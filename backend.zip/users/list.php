<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requireAuth(['admin_gudang']);

$pdo = getDB();
$stmt = $pdo->query("SELECT id, username, full_name, role, permissions, created_at FROM users ORDER BY created_at ASC");
$users = $stmt->fetchAll();

foreach ($users as &$u) {
    $decoded = !empty($u['permissions']) ? json_decode($u['permissions'], true) : [];
    $u['permissions'] = is_array($decoded) ? $decoded : [];
}
unset($u);

echo json_encode(['success' => true, 'data' => $users]);
