<?php
require_once __DIR__ . '/db_config.php';

// ALLOWED_ORIGIN bisa berisi lebih dari 1 origin, dipisah koma
// (mis. domain utama + username.github.io). Browser hanya menerima
// SATU origin di header, jadi kita cocokkan origin request saat ini
// terhadap daftar yang diizinkan.
$allowedOrigins = array_map('trim', explode(',', ALLOWED_ORIGIN));
$requestOrigin  = $_SERVER['HTTP_ORIGIN'] ?? '';

if (in_array($requestOrigin, $allowedOrigins, true)) {
    header("Access-Control-Allow-Origin: " . $requestOrigin);
} else {
    header("Access-Control-Allow-Origin: " . $allowedOrigins[0]);
}
header("Vary: Origin");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

// Preflight request dari browser - langsung balas OK tanpa body
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
