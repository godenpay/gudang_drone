<?php
// ============================================================
// KONFIGURASI DATABASE & KEAMANAN - dibaca dari .env
// ============================================================

require_once __DIR__ . '/../helpers/env_loader.php';
load_env(__DIR__ . '/../.env.backend'); // sesuaikan path/nama file .env kamu

define('DB_HOST', getenv('DB_HOST'));
define('DB_NAME', getenv('DB_NAME'));
define('DB_USER', getenv('DB_USER'));
define('DB_PASS', getenv('DB_PASS'));

define('JWT_SECRET', getenv('JWT_SECRET'));

define('ALLOWED_ORIGIN', getenv('ALLOWED_ORIGIN'));
