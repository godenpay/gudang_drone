<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

// Hapus riwayat transaksi = tindakan koreksi/void, bukan sekadar hapus baris.
// Dibatasi admin_gudang saja karena ini menyangkut integritas data stok & audit trail.
requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$id = $_GET['id'] ?? '';
if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID transaksi wajib disertakan.']);
    exit;
}

$pdo = getDB();

$stmt = $pdo->prepare("SELECT * FROM transactions WHERE id = ?");
$stmt->execute([$id]);
$trx = $stmt->fetch();

if (!$trx) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Transaksi tidak ditemukan.']);
    exit;
}

$itemStmt = $pdo->prepare("SELECT stock FROM inventory WHERE id = ?");
$itemStmt->execute([$trx['item_id']]);
$item = $itemStmt->fetch();

if (!$item) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => 'Barang terkait transaksi ini sudah tidak ada di master data, transaksi tidak bisa dihapus otomatis.']);
    exit;
}

$currentStock = (int)$item['stock'];
$qty = (int)$trx['qty'];

if ($trx['type'] === 'INBOUND') {
    // Membatalkan barang masuk = stok berkurang. Cegah kalau unit itu sudah
    // "dipakai" (stok saat ini lebih kecil dari qty yang mau dibatalkan),
    // supaya stok tidak jadi negatif / tidak masuk akal.
    if ($currentStock - $qty < 0) {
        http_response_code(409);
        echo json_encode([
            'success' => false,
            'message' => "Tidak bisa menghapus: stok saat ini ({$currentStock}) sudah kurang dari qty transaksi ini ({$qty}). Sebagian unit dari transaksi ini kemungkinan sudah keluar lagi lewat transaksi lain.",
        ]);
        exit;
    }
    $newStock = $currentStock - $qty;
} else {
    // Membatalkan barang keluar = stok bertambah kembali.
    $newStock = $currentStock + $qty;
}

$pdo->beginTransaction();
try {
    $upd = $pdo->prepare("UPDATE inventory SET stock = ? WHERE id = ?");
    $upd->execute([$newStock, $trx['item_id']]);

    $del = $pdo->prepare("DELETE FROM transactions WHERE id = ?");
    $del->execute([$id]);

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Gagal menghapus transaksi, coba lagi.']);
    exit;
}

echo json_encode(['success' => true, 'message' => 'Transaksi berhasil dihapus dan stok sudah disesuaikan kembali.']);
