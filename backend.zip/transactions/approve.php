<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

// Hanya Admin Gudang yang boleh approve permintaan outbound dari staff.
requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$id = trim($input['id'] ?? '');

if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID transaksi wajib diisi.']);
    exit;
}

$pdo = getDB();
$pdo->beginTransaction();

try {
    $stmt = $pdo->prepare("SELECT id, item_id, item_name, qty, status FROM transactions WHERE id = ? FOR UPDATE");
    $stmt->execute([$id]);
    $trx = $stmt->fetch();

    if (!$trx) {
        throw new Exception('Transaksi tidak ditemukan.');
    }
    if ($trx['status'] !== 'Menunggu Approval') {
        throw new Exception('Transaksi ini sudah diproses sebelumnya.');
    }

    $itemStmt = $pdo->prepare("SELECT stock FROM inventory WHERE id = ? FOR UPDATE");
    $itemStmt->execute([$trx['item_id']]);
    $item = $itemStmt->fetch();

    if (!$item || $item['stock'] < $trx['qty']) {
        throw new Exception('Stok tidak lagi mencukupi untuk approve permintaan ini. Stok saat ini: ' . ($item['stock'] ?? 0));
    }

    $pdo->prepare("UPDATE inventory SET stock = stock - ? WHERE id = ?")
        ->execute([$trx['qty'], $trx['item_id']]);

    $pdo->prepare("UPDATE transactions SET status = 'Selesai' WHERE id = ?")
        ->execute([$id]);

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => "Outbound {$trx['qty']} unit {$trx['item_name']} disetujui."]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
