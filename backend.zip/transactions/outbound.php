<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

$payload = requirePermission('outbound');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$itemId      = trim($input['item_id'] ?? '');
$qty         = (int)($input['qty'] ?? 0);
$destination = trim($input['destination'] ?? '');

if ($itemId === '' || $qty <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Barang dan kuantitas wajib diisi dengan benar.']);
    exit;
}

$pdo = getDB();
$pdo->beginTransaction();

try {
    $stmt = $pdo->prepare("SELECT id, name, stock FROM inventory WHERE id = ? FOR UPDATE");
    $stmt->execute([$itemId]);
    $item = $stmt->fetch();

    if (!$item) {
        throw new Exception('Barang tidak ditemukan.');
    }

    if ($item['stock'] < $qty) {
        throw new Exception("Stok tidak mencukupi! Stok saat ini: {$item['stock']}");
    }

    $trxId = 'TRX-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
    $isStaff = $payload['role'] === 'staff';
    $status  = $isStaff ? 'Menunggu Approval' : 'Selesai';

    $insert = $pdo->prepare("INSERT INTO transactions (id, type, item_id, item_name, qty, destination, status, created_by)
                              VALUES (?, 'OUTBOUND', ?, ?, ?, ?, ?, ?)");
    $insert->execute([$trxId, $itemId, $item['name'], $qty, $destination, $status, $payload['user_id']]);

    // Stok baru dikurangi setelah Admin Gudang approve (lihat transactions/approve.php).
    if (!$isStaff) {
        $update = $pdo->prepare("UPDATE inventory SET stock = stock - ? WHERE id = ?");
        $update->execute([$qty, $itemId]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => $isStaff
            ? "Permintaan outbound {$qty} unit {$item['name']} dikirim, menunggu approval Admin Gudang."
            : "Berhasil mengeluarkan {$qty} unit {$item['name']} dari gudang.",
        'trx_id'  => $trxId,
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
