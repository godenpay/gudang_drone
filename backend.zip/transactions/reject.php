<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$id = trim($input['id'] ?? '');

if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID transaksi wajib diisi.']);
    exit;
}

$pdo = getDB();

$stmt = $pdo->prepare("SELECT id, item_name, qty, status FROM transactions WHERE id = ?");
$stmt->execute([$id]);
$trx = $stmt->fetch();

if (!$trx) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Transaksi tidak ditemukan.']);
    exit;
}
if ($trx['status'] !== 'Menunggu Approval') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Transaksi ini sudah diproses sebelumnya.']);
    exit;
}

// Stok belum pernah dikurangi saat pending, jadi reject cukup ubah status saja.
$pdo->prepare("UPDATE transactions SET status = 'Ditolak' WHERE id = ?")->execute([$id]);

echo json_encode(['success' => true, 'message' => "Permintaan outbound {$trx['qty']} unit {$trx['item_name']} ditolak."]);
