<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requireAuth();

$pdo = getDB();
$stmt = $pdo->query("
    SELECT t.id, t.type, t.item_id, t.item_name AS item, t.qty, t.supplier,
           t.po_number AS poNumber, t.destination, t.status,
           t.created_at AS date, u.full_name AS createdBy
    FROM transactions t
    LEFT JOIN users u ON u.id = t.created_by
    ORDER BY t.created_at DESC
");

echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
