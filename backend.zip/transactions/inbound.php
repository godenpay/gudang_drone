<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

$payload = requirePermission('inbound');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$itemId   = trim($input['item_id'] ?? '');
$qty      = (int)($input['qty'] ?? 0);
$supplier = trim($input['supplier'] ?? '');
$poNumber = trim($input['po_number'] ?? '');

if ($itemId === '' || $qty <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Barang dan kuantitas wajib diisi dengan benar.']);
    exit;
}

$pdo = getDB();
$pdo->beginTransaction();

try {
    // FOR UPDATE: kunci baris agar aman dari race condition jika ada input bersamaan
    $stmt = $pdo->prepare("SELECT id, name FROM inventory WHERE id = ? FOR UPDATE");
    $stmt->execute([$itemId]);
    $item = $stmt->fetch();

    if (!$item) {
        throw new Exception('Barang tidak ditemukan.');
    }

    $trxId = 'TRX-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));

    $insert = $pdo->prepare("INSERT INTO transactions (id, type, item_id, item_name, qty, supplier, po_number, status, created_by)
                              VALUES (?, 'INBOUND', ?, ?, ?, ?, ?, 'Selesai', ?)");
    $insert->execute([$trxId, $itemId, $item['name'], $qty, $supplier, $poNumber, $payload['user_id']]);

    $update = $pdo->prepare("UPDATE inventory SET stock = stock + ? WHERE id = ?");
    $update->execute([$qty, $itemId]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => "Berhasil menambahkan {$qty} unit {$item['name']} ke gudang.",
        'trx_id'  => $trxId,
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
