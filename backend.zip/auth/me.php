<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

$payload = requireAuth();

$pdo = getDB();
$stmt = $pdo->prepare("SELECT id, username, full_name, role, permissions FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$payload['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'User tidak ditemukan.']);
    exit;
}

$permissions = [];
if (!empty($user['permissions'])) {
    $decoded = json_decode($user['permissions'], true);
    if (is_array($decoded)) {
        $permissions = $decoded;
    }
}
$user['permissions'] = $permissions;

echo json_encode(['success' => true, 'user' => $user]);
