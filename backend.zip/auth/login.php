<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');
$password = (string)($input['password'] ?? '');

if ($username === '' || $password === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username dan password wajib diisi.']);
    exit;
}

$pdo = getDB();
$stmt = $pdo->prepare("SELECT id, username, password_hash, full_name, role, permissions FROM users WHERE username = ? LIMIT 1");
$stmt->execute([$username]);
$user = $stmt->fetch();

// Pesan error sengaja disamakan (tidak bocorkan mana yang salah: username atau password)
if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Username atau password salah.']);
    exit;
}

$permissions = [];
if (!empty($user['permissions'])) {
    $decoded = json_decode($user['permissions'], true);
    if (is_array($decoded)) {
        $permissions = $decoded;
    }
}

$token = generateJWT([
    'user_id'  => $user['id'],
    'username' => $user['username'],
    'role'     => $user['role'],
]);

echo json_encode([
    'success' => true,
    'token'   => $token,
    'user'    => [
        'id'          => $user['id'],
        'username'    => $user['username'],
        'full_name'   => $user['full_name'],
        'role'        => $user['role'],
        'permissions' => $permissions,
    ],
]);
