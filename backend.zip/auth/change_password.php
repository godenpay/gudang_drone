<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$payload = requireAuth(); // semua role yang login boleh ganti password sendiri

$input = json_decode(file_get_contents('php://input'), true);
$oldPassword = (string)($input['old_password'] ?? '');
$newPassword = (string)($input['new_password'] ?? '');

if ($oldPassword === '' || $newPassword === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password lama dan baru wajib diisi.']);
    exit;
}

if (strlen($newPassword) < 8) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password baru minimal 8 karakter.']);
    exit;
}

$pdo = getDB();

$stmt = $pdo->prepare("SELECT id, password_hash FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$payload['user_id']]);
$user = $stmt->fetch();

if (!$user || !password_verify($oldPassword, $user['password_hash'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password lama salah.']);
    exit;
}

$newHash = password_hash($newPassword, PASSWORD_DEFAULT);

$update = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
$update->execute([$newHash, $user['id']]);

echo json_encode(['success' => true, 'message' => 'Password berhasil diganti.']);
