<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requireAuth(); // Admin Gudang & Manajer sama-sama boleh lihat

$pdo = getDB();

// Auto-tandai keterlambatan setiap kali daftar diambil, tanpa perlu cron job.
$pdo->exec("UPDATE loans SET status = 'Terlambat'
            WHERE status = 'Dipinjam' AND expected_return_date < CURDATE()");

$stmt = $pdo->query("SELECT id, item_id, item_name, qty, borrower_name, project_name, notes,
                             loan_date, expected_return_date, actual_return_date,
                             condition_note, status, created_by, created_at
                      FROM loans ORDER BY created_at DESC");

echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
