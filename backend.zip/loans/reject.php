<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$id = trim($input['id'] ?? '');

if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID peminjaman wajib diisi.']);
    exit;
}

$pdo = getDB();

$stmt = $pdo->prepare("SELECT id, item_name, qty, status FROM loans WHERE id = ?");
$stmt->execute([$id]);
$loan = $stmt->fetch();

if (!$loan) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Peminjaman tidak ditemukan.']);
    exit;
}
if ($loan['status'] !== 'Menunggu Approval') {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => 'Peminjaman ini sudah diproses sebelumnya.']);
    exit;
}

$pdo->prepare("UPDATE loans SET status = 'Ditolak' WHERE id = ?")->execute([$id]);

echo json_encode(['success' => true, 'message' => "Permintaan peminjaman {$loan['qty']} unit {$loan['item_name']} ditolak."]);
