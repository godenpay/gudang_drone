<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

// Form peminjaman dibuat oleh Admin Gudang ATAU Manajer.
$payload = requirePermission('loans');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

$itemId       = trim($input['item_id'] ?? '');
$qty          = (int)($input['qty'] ?? 0);
$borrowerName = trim($input['borrower_name'] ?? '');
$projectName  = trim($input['project_name'] ?? '');
$notes        = trim($input['notes'] ?? '');
$loanDate     = trim($input['loan_date'] ?? '');
$returnDate   = trim($input['expected_return_date'] ?? '');

if ($itemId === '' || $qty <= 0 || $borrowerName === '' || $projectName === '' || $loanDate === '' || $returnDate === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Barang, kuantitas, peminjam, project, tanggal pinjam, dan target kembali wajib diisi.']);
    exit;
}

if (strtotime($returnDate) < strtotime($loanDate)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Target tanggal kembali tidak boleh sebelum tanggal pinjam.']);
    exit;
}

$pdo = getDB();
$pdo->beginTransaction();

try {
    $stmt = $pdo->prepare("SELECT id, name, category, purpose, stock FROM inventory WHERE id = ? FOR UPDATE");
    $stmt->execute([$itemId]);
    $item = $stmt->fetch();

    if (!$item) {
        throw new Exception('Barang tidak ditemukan.');
    }

    if ($item['category'] !== 'Drone' || $item['purpose'] !== 'Demo-Project') {
        throw new Exception('Hanya drone dari stok Demo/Project yang dapat dipinjamkan. Untuk stok jual, gunakan menu Outbound.');
    }

    if ($item['stock'] < $qty) {
        throw new Exception("Stok demo tidak mencukupi! Stok tersedia: {$item['stock']}");
    }

    $loanId  = 'LOAN-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
    $isStaff = $payload['role'] === 'staff';
    $status  = $isStaff ? 'Menunggu Approval' : 'Dipinjam';

    $insert = $pdo->prepare("INSERT INTO loans
        (id, item_id, item_name, qty, borrower_name, project_name, notes, loan_date, expected_return_date, status, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $insert->execute([$loanId, $itemId, $item['name'], $qty, $borrowerName, $projectName, $notes, $loanDate, $returnDate, $status, $payload['user_id']]);

    // Stok baru dikurangi setelah Admin Gudang approve (lihat loans/approve.php).
    if (!$isStaff) {
        $update = $pdo->prepare("UPDATE inventory SET stock = stock - ? WHERE id = ?");
        $update->execute([$qty, $itemId]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => $isStaff
            ? "Permintaan peminjaman {$qty} unit {$item['name']} dikirim, menunggu approval Admin Gudang."
            : "Peminjaman {$qty} unit {$item['name']} untuk project \"{$projectName}\" berhasil dicatat.",
        'loan_id' => $loanId,
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
