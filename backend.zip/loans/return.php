<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

// Pengembalian juga boleh dicatat oleh Admin Gudang atau Manajer.
requirePermission('loans');

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$id = $_GET['id'] ?? '';
if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID peminjaman wajib disertakan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$conditionNote = trim($input['condition_note'] ?? '');

$pdo = getDB();
$pdo->beginTransaction();

try {
    $stmt = $pdo->prepare("SELECT id, item_id, item_name, qty, status FROM loans WHERE id = ? FOR UPDATE");
    $stmt->execute([$id]);
    $loan = $stmt->fetch();

    if (!$loan) {
        throw new Exception('Data peminjaman tidak ditemukan.');
    }

    if ($loan['status'] === 'Dikembalikan') {
        throw new Exception('Peminjaman ini sudah tercatat dikembalikan.');
    }

    $update = $pdo->prepare("UPDATE loans SET status = 'Dikembalikan', actual_return_date = CURDATE(), condition_note = ? WHERE id = ?");
    $update->execute([$conditionNote, $id]);

    $stock = $pdo->prepare("UPDATE inventory SET stock = stock + ? WHERE id = ?");
    $stock->execute([$loan['qty'], $loan['item_id']]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => "{$loan['qty']} unit {$loan['item_name']} berhasil dicatat kembali ke stok demo.",
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
