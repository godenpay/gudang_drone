<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../helpers/auth_middleware.php';
require_once __DIR__ . '/../config/database.php';

requireAuth(['admin_gudang']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$id = trim($input['id'] ?? '');

if ($id === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID peminjaman wajib diisi.']);
    exit;
}

$pdo = getDB();
$pdo->beginTransaction();

try {
    $stmt = $pdo->prepare("SELECT id, item_id, item_name, qty, status FROM loans WHERE id = ? FOR UPDATE");
    $stmt->execute([$id]);
    $loan = $stmt->fetch();

    if (!$loan) {
        throw new Exception('Peminjaman tidak ditemukan.');
    }
    if ($loan['status'] !== 'Menunggu Approval') {
        throw new Exception('Peminjaman ini sudah diproses sebelumnya.');
    }

    $itemStmt = $pdo->prepare("SELECT stock FROM inventory WHERE id = ? FOR UPDATE");
    $itemStmt->execute([$loan['item_id']]);
    $item = $itemStmt->fetch();

    if (!$item || $item['stock'] < $loan['qty']) {
        throw new Exception('Stok demo tidak lagi mencukupi untuk approve permintaan ini. Stok saat ini: ' . ($item['stock'] ?? 0));
    }

    $pdo->prepare("UPDATE inventory SET stock = stock - ? WHERE id = ?")
        ->execute([$loan['qty'], $loan['item_id']]);

    $pdo->prepare("UPDATE loans SET status = 'Dipinjam' WHERE id = ?")
        ->execute([$id]);

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => "Peminjaman {$loan['qty']} unit {$loan['item_name']} disetujui."]);
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
